
public class VahnichenkoNY3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int rage= 18;
		
		System.out.print("������ ");
		System.out.println("18");
		
		System.out.println("������ " + rage);

	}

}
